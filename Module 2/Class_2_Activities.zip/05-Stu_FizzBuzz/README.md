# Fizz Buzz

In this activity, you'll work on a popular logic problem that countless coders have encountered in technical interviews.

## Instructions

Create a VBA script that populates the second column with the word "Fizz", "Buzz", or "Fizzbuzz" based on the value in the first column.

* If the value in Column 1 is a multiple of both 3 and 5, print "Fizzbuzz" in Column 2.

* If the value in Column 1 is a multiple of just 3, print "Fizz" in Column 2.

* If the value in Column 1 is a multiple of just 5, print "Buzz" in Column 2.

## Hint

Remember the mod!

—

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
