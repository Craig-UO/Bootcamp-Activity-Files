# Credit Card Checker

In this activity, you will practice comparing cells to calculate the total transaction amount for different credit card brands.

## Instructions

* Create a VBA script that will process the credit card purchases by identifying each of the unique brands listed.

* Create a single pop-up message for each of the credit card brands listed by looping through the list.

## Bonus

Add up the total value of credit card purchases for each brand, and put the information in the summary table.


## Note

* This assignment is extremely similar to the basic version of the homework assignment, so let's buckle down and analyze our work!

—
© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
