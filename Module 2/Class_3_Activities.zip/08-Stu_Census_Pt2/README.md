# U.S. Census, Part 2

In this second part of this activity, you will combine all the worksheets into one massive table in a new sheet.

## Instructions

* Loop through every worksheet, and select the year contents.

* Copy the year contents, and paste them into the `Combined_Data` tab.

## References

Data Source: [U.S. Census API - ACS 5-Year Estimates 2016-2019](https://www.census.gov/data/developers/data-sets/census-microdata-api.ACS_5-Year_PUMS.html)

—

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
