# Adding More to the Repo

In this activity, you will create a new repository, clone it, and add files via command line

## Instructions

* Using the repo that we just created, make or add the following changes:


* Add new lines of code to one of the Python files.
* Create a new folder.
* Add a file to the newly created folder.
* Add, commit, and push the changes.
* Delete the new folder.
* Add, commit, and push the changes again.

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
