# Creates a variable with a string "Frankfurter"

# Creates a variable with an integer 80

# Creates a variable with the boolean value of True

# Prints a statement adding the variable

# Convert the integer years into a string and prints

# Converts a boolean into a string and prints

# An f-string accepts all data types without conversion
