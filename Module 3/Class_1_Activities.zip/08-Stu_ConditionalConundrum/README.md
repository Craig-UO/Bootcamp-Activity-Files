# Conditionals Conundrum

In this activity, you’ll review prewritten conditionals and predict the lines that will be printed to the console.

## Instructions

* Go through the conditionals in the provided code, and predict the lines that will be printed to the console.

* Do not run the code at first. Try to follow the thought process for each chunk of code and then make a guess. Only after coming up with a guess for each section should you run the application.

—

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
